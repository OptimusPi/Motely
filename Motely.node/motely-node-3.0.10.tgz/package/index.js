import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
function _dir() {
    return dirname(fileURLToPath(import.meta.url));
}
function resolveRid() {
    switch (process.platform) {
        case 'win32':
            return `win-${process.arch === 'ia32' ? 'x86' : process.arch}`;
        case 'darwin':
            return `osx-${process.arch}`;
        default:
            return `${process.platform}-${process.arch === 'ia32' ? 'x86' : process.arch}`;
    }
}
function loadRawExports(addonModulePath) {
    const require = createRequire(import.meta.url);
    const mod = require(addonModulePath);
    if ('MotelyNodeExports' in mod && mod.MotelyNodeExports) {
        return mod.MotelyNodeExports;
    }
    return mod;
}
function normalizeAnteAnalysis(ante) {
    return {
        ...ante,
        drawOrder: typeof ante.drawOrder === 'string' ? ante.drawOrder : '',
        shopQueue: Array.isArray(ante.shopQueue) ? ante.shopQueue : [],
        packs: Array.isArray(ante.packs) ? ante.packs : [],
    };
}
function normalizeSeedAnalysis(result) {
    return {
        ...result,
        erraticDeckComposition: Array.isArray(result.erraticDeckComposition)
            ? result.erraticDeckComposition.filter((value) => typeof value === 'string')
            : [],
        antes: Array.isArray(result.antes)
            ? result.antes.map(normalizeAnteAnalysis)
            : [],
    };
}
function buildApi(raw, cachedCapabilities, pollIntervalMs) {
    let disposed = false;
    return {
        async getCapabilities() {
            return cachedCapabilities;
        },
        getAvailableThreadCount() {
            return cachedCapabilities.availableThreadCount;
        },
        async analyzeSeed(seed, deck, stake) {
            const json = await raw.analyzeSeedAsync(seed, deck, stake);
            const result = JSON.parse(json);
            if (result.error && !result.seed)
                throw new Error(result.error);
            return normalizeSeedAnalysis(result);
        },
        async validateJaml(jaml) {
            const json = await raw.validateJamlAsync(jaml);
            return JSON.parse(json);
        },
        async startJamlSearch(jamlContent, options) {
            if (disposed) {
                throw new Error('Motely instance has been disposed');
            }
            const { onProgress, onResult, ...searchParams } = options ?? {};
            const optionsJson = JSON.stringify({
                threadCount: Math.max(1, searchParams.threadCount ?? cachedCapabilities.availableThreadCount ?? 1),
                batchCharCount: 4,
                palindrome: searchParams.palindrome ?? !(searchParams.specificSeed || searchParams.randomSeeds),
                ...searchParams,
            });
            const results = [];
            const seen = new Set();
            const applyStatus = (status) => {
                onProgress?.(status.totalSeedsSearched, status.matchingSeeds, status.elapsedMs, status.resultCount);
                for (const result of status.results ?? []) {
                    const key = `${result.seed}:${result.score}`;
                    if (seen.has(key))
                        continue;
                    seen.add(key);
                    results.push(result);
                    onResult?.(result.seed, result.score);
                }
            };
            const completionPromise = raw.startJamlSearch(jamlContent, optionsJson)
                .then(json => ({ kind: 'done', json }))
                .catch(error => ({ kind: 'error', error }));
            while (true) {
                const next = await Promise.race([
                    completionPromise,
                    new Promise(resolve => setTimeout(() => resolve({ kind: 'tick' }), pollIntervalMs)),
                ]);
                if (next.kind === 'error') {
                    throw next.error;
                }
                if (next.kind === 'done') {
                    const status = JSON.parse(next.json);
                    if (status.error)
                        throw new Error(status.error);
                    applyStatus(status);
                    return results;
                }
                const statusJson = await raw.getSearchStatus();
                const status = JSON.parse(statusJson);
                if (status.error) {
                    if (status.error === 'No active search')
                        continue;
                    throw new Error(status.error);
                }
                applyStatus(status);
            }
        },
        dispose() {
            disposed = true;
            try {
                raw.stopSearch();
            }
            catch {
            }
            void raw.disposeSearch();
        },
    };
}
/**
 * Load the Motely native Node addon. Call once at startup; reuse the returned API.
 */
export async function loadMotely(options) {
    const addonModulePath = options?.addonPath
        ?? join(options?.addonDirectory ?? options?.frameworkPath ?? join(_dir(), 'addon'), resolveRid(), 'Motely.NodeAddon.node');
    const raw = loadRawExports(addonModulePath);
    const capabilitiesJson = await raw.getCapabilitiesAsync();
    const cachedCapabilities = JSON.parse(capabilitiesJson);
    return buildApi(raw, cachedCapabilities, Math.max(25, options?.pollIntervalMs ?? 100));
}

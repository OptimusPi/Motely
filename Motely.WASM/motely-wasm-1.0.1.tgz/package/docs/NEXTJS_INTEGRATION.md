# Integrating motely-wasm (v1.0.1) into Next.js

## 1. TypeScript types / API

Install and use the package types:

```bash
npm install motely-wasm
```

The package ships types via `"types": "motely-wasm.d.ts"`. Import them:

```typescript
import type {
  MotelyWasmApi,
  SeedAnalysisResult,
  AnteAnalysis,
  SearchResponse,
  SearchHit,
  SearchProgress,
  ValidateResult,
  ErrorResult,
  VersionInfo,
} from 'motely-wasm';
```

### Exported API (all methods live on `Motely.WASM.MotelyWasm` after load)

| Method | Parameters | Returns |
|--------|------------|--------|
| `AnalyzeSeed` | `(seed, deck, stake, minAnte, maxAnte, optionsJson)` | `Promise<string>` — JSON: `SeedAnalysisResult` or `ErrorResult` |
| `SearchSeeds` | `(jamlFilterJson, seedList \| null, threadCount, maxResults?)` | `Promise<string>` — JSON: `SearchResponse` or `ErrorResult` |
| `ValidateJaml` | `(jamlString)` | `Promise<string>` — JSON: `ValidateResult` |
| `CancelSearch` | — | `Promise<void>` |
| `IsSearchRunning` | — | `Promise<boolean>` |
| `GetSearchProgress` | — | `Promise<string>` — JSON: `SearchProgress` |
| `GetLastSearchResult` | — | `Promise<string>` — JSON: `SearchResponse` or empty |
| `GetProcessorCount` | — | `Promise<number>` |
| `GetVersion` | — | `Promise<string>` — JSON: `VersionInfo` |

### Key interfaces (returned as JSON strings; parse with `JSON.parse()`)

```typescript
// AnalyzeSeed result
interface SeedAnalysisResult {
  seed: string;
  deck: string;
  stake: string;
  erraticDeckComposition: string[];
  twos: number;
  antes: AnteAnalysis[];
}

// SearchSeeds result
interface SearchResponse {
  results: SearchHit[];   // empty if using callbacks
  totalSearched: number;
  foundCount: number;
  cancelled: boolean;
}

interface SearchHit {
  seed: string;
  score: number;
  tallies?: number[];
}

// Optional callbacks (set on globalThis before SearchSeeds)
globalThis.MotelyWasmOnProgress = (progressJson: string) => void;
globalThis.MotelyWasmOnResult = (seed: string, score: number, talliesStr: string) => void;
globalThis.MotelyWasmOnComplete = (resultJson: string) => void;
```

---

## 2. Minimal usage example

### Put WASM in `public` (run when you need it)

From your app:

```bash
npx motely-wasm-prepare
```

This copies `node_modules/motely-wasm/dist` to `public/motely-wasm`. Optional: `npx motely-wasm-prepare public/my-wasm`. Or add to `package.json`: `"prepare:wasm": "motely-wasm-prepare"` and run `npm run prepare:wasm`. Alternatively use `require('motely-wasm').getDistPath()` in your own script.

### Client-side loader (run only in browser; use dynamic import so Next doesn’t bundle WASM)

```typescript
// lib/motely-wasm.ts
import type { MotelyWasmApi } from 'motely-wasm';

let api: MotelyWasmApi | null = null;

export async function getMotelyWasm(): Promise<MotelyWasmApi> {
  if (api) return api;

  const base = '/motely-wasm'; // must match where you copied dist (e.g. public/motely-wasm)
  const { dotnet } = await import(/* webpackIgnore: true */ `${base}/_framework/dotnet.js`);
  const { getAssemblyExports, getConfig } = await dotnet.create();
  const exports = await getAssemblyExports(getConfig().mainAssemblyName);
  api = exports.Motely.WASM.MotelyWasm as MotelyWasmApi;
  return api;
}
```

### Example: validate JAML and run a search

```typescript
// In a Client Component ('use client')
'use client';

import { useState } from 'react';
import { getMotelyWasm } from '@/lib/motely-wasm';
import type { SearchResponse, SearchHit, ValidateResult } from 'motely-wasm';

export default function SearchPage() {
  const [jaml, setJaml] = useState('');
  const [results, setResults] = useState<SearchHit[]>([]);
  const [status, setStatus] = useState<string>('');

  async function runSearch() {
    const motely = await getMotelyWasm();

    const validateJson = await motely.ValidateJaml(jaml);
    const validate = JSON.parse(validateJson) as ValidateResult;
    if (!validate.valid) {
      setStatus(`Invalid JAML: ${validate.error ?? 'unknown'}`);
      return;
    }

    setStatus('Searching...');
    const threadCount = await motely.GetProcessorCount();
    const resultJson = await motely.SearchSeeds(jaml, null, threadCount, 1000);
    const result = JSON.parse(resultJson) as SearchResponse;

    if (result.error) {
      setStatus(`Error: ${result.error}`);
      return;
    }
    setResults(result.results);
    setStatus(`Found ${result.foundCount} seeds (searched ${result.totalSearched})`);
  }

  return (
    <div>
      <textarea value={jaml} onChange={(e) => setJaml(e.target.value)} />
      <button onClick={runSearch}>Search</button>
      <p>{status}</p>
      <ul>
        {results.map((hit) => (
          <li key={hit.seed}>{hit.seed} (score: {hit.score})</li>
        ))}
      </ul>
    </div>
  );
}
```

### Example: analyze a single seed

```typescript
const motely = await getMotelyWasm();
const resultJson = await motely.AnalyzeSeed('TACO1111', 'Red', 'White', 1, 8, '{}');
const analysis = JSON.parse(resultJson); // SeedAnalysisResult or ErrorResult
```

---

## 3. Browser compatibility and Next.js config

- **WASM must run in the browser.** Use the loader only in client code (e.g. `'use client'` or inside `useEffect` / event handlers). Do not import or call it from server components or API routes.
- **Serve WASM from `public`.** Copy `node_modules/motely-wasm/dist/` to e.g. `public/motely-wasm/` so the app can load `/motely-wasm/_framework/dotnet.js` and related files. Next.js serves `public/` at the root.
- **Multi-threading requires COOP/COEP.** For shared memory (faster search), the page must be served with:
  ```
  Cross-Origin-Embedder-Policy: require-corp
  Cross-Origin-Opener-Policy: same-origin
  ```
  In Next.js you can set these in `next.config.js` via `headers()` for the routes that load WASM, or configure them on your host (Vercel, etc.).
- **No special Next.js config for WASM.** You do not need to add WASM to `transpilePackages` or other Next config for the runtime. Just copy the built WASM files to `public` and load them via dynamic `import()` from the client as shown above.

Example `next.config.js` headers (optional; only if you need COOP/COEP for the whole app):

```js
// next.config.js
module.exports = {
  async headers() {
    return [
      {
        source: '/:path*',
        headers: [
          { key: 'Cross-Origin-Embedder-Policy', value: 'require-corp' },
          { key: 'Cross-Origin-Opener-Policy', value: 'same-origin' },
        ],
      },
    ];
  },
};
```

Without these headers, motely-wasm still runs but single-threaded (slower for large searches).

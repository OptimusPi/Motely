#!/usr/bin/env node
/**
 * Copies motely-wasm dist from node_modules to your app's public dir.
 * Run from your app: npx motely-wasm-prepare
 * Or add to package.json: "prepare:wasm": "motely-wasm-prepare"
 *
 * Usage: motely-wasm-prepare [destination]
 * Default destination: public/motely-wasm (relative to cwd)
 */
const fs = require('fs');
const path = require('path');

const destArg = process.argv[2];
const dest = path.resolve(process.cwd(), destArg || path.join('public', 'motely-wasm'));

// Resolve package dist: this script lives in node_modules/motely-wasm/scripts/
const pkgRoot = path.join(__dirname, '..');
const src = path.join(pkgRoot, 'dist');

if (!fs.existsSync(src)) {
  console.error('motely-wasm: dist not found at', src);
  process.exit(1);
}

try {
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  fs.cpSync(src, dest, { recursive: true });
  console.log('motely-wasm: copied to', dest);
} catch (err) {
  console.error('motely-wasm:', err.message);
  process.exit(1);
}

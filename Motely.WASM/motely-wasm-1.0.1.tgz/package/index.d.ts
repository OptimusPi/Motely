/**
 * Node/build-script entry: get paths to WASM files so you can copy dist/ to public.
 * For browser API types and loadMotely, use the default (ESM) entry.
 */
export function getDistPath(): string;
export function getFrameworkPath(): string;

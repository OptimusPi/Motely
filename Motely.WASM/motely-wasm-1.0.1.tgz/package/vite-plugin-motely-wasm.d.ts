import type { Plugin } from 'vite';

export interface MotelyWasmViteOptions {
  /** URL base for WASM in dev and in build output (default: '/motely-wasm') */
  virtualBase?: string;
}

/**
 * Serves WASM from node_modules in dev; emits to build output in prod. Does not write to your source tree.
 */
export function motelyWasm(options?: MotelyWasmViteOptions): Plugin;

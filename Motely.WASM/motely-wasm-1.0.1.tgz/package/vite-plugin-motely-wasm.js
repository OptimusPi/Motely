/**
 * Vite plugin: serves motely-wasm from node_modules (dev) and emits to build output (prod).
 * Does not write into the consumer's source tree.
 *
 * Usage:
 *   import { motelyWasm } from 'motely-wasm/vite';
 *   export default defineConfig({ plugins: [motelyWasm(), vue()] });
 */
const path = require('path');
const fs = require('fs');

function getDistPath() {
  return path.join(__dirname, 'dist');
}

/**
 * @param {{ virtualBase?: string }} [options] - URL base in dev and in output (default '/motely-wasm')
 * @returns {import('vite').Plugin}
 */
function motelyWasm(options = {}) {
  const virtualBase = (options.virtualBase ?? '/motely-wasm').replace(/\/$/, '');
  const srcDir = getDistPath();

  return {
    name: 'motely-wasm',
    configureServer(server) {
      if (!fs.existsSync(srcDir)) {
        server.config.logger.warn('[motely-wasm] dist not found at ' + srcDir);
        return;
      }
      server.middlewares.use(virtualBase, (req, res, next) => {
        const url = req.url === '' || req.url === '/' ? '/index.html' : req.url;
        const file = path.join(srcDir, url.replace(/^\//, ''));
        if (!file.startsWith(srcDir) || !fs.existsSync(file) || !fs.statSync(file).isFile()) {
          return next();
        }
        res.setHeader('Cross-Origin-Embedder-Policy', 'require-corp');
        res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
        const stream = fs.createReadStream(file);
        stream.pipe(res);
      });
    },
    closeBundle() {
      if (!fs.existsSync(srcDir)) return;
      const outDir = this.config.build.outDir;
      const dest = path.join(outDir, virtualBase.replace(/^\//, ''));
      try {
        fs.mkdirSync(path.dirname(dest), { recursive: true });
        fs.cpSync(srcDir, dest, { recursive: true });
        this.config.logger.info('[motely-wasm] emitted to ' + dest);
      } catch (err) {
        this.config.logger.warn('[motely-wasm] emit failed: ' + err.message);
      }
    },
  };
}

module.exports = { motelyWasm };
